package com.example.hw4_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
